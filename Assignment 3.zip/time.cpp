#include <iostream>
using namespace std ;
/*using namespace std;Q2. Write a class for Time and provide the functionality
Time()
Time(int h,int m,int s)
getHour()
getMinute()
getSeconds()
printTime()
setHour()
setMinute()
setSeconds()
Allocate the memory for the the object dynamically and test the functunalities using time ptr.

 */

class Time
{
    int h;
    int m;
    int s;

public:
    Time():h(12),m(0),s(0){}
    Time(int h, int m, int s)
    {
        this->h = h;
        this->m = m;
        this->s = s;
    }
    int getHour(int h)
    {
        return h;
    }
    int getMinute()
    {
        return m;
    }
    int getSeconds(int s)
    {
        return s;
    }
    void setHour(int h)
    {
        this->h = h;
    }
    void setMinute(int m)
    {
        this->m = m;
    }
    void setSeconds(int s)
    {
        this->s = s;
    }
    void printTime()
    {
        cout<< "The time is (hh:mm:ss) :" << h << ":" << m << ":" << s <<endl ;
    }
};
int main()
{  
    Time *ptr ;
    ptr=new Time(12,23,34);
    ptr->printTime();
    Time *ptr1;
    ptr1= new Time();
    ptr1->printTime();
    


    return 0;
}