#include <iostream>
using namespace std;

class Cylinder
{
    const static double pi;
    double radius;
    double height;

public:
    Cylinder() : radius(1), height(1) {}
    Cylinder(double radius, double height)
    {
        this->radius = radius;
        this->height = height;
    }
    void setRadius(double radius)
    {
        this->radius = radius;
    }
    double getRadius(double radius)
    {
        return radius;
    }
    void setHeight(double height)
    {
        this->height = height;
    }
    double getHeight(double height)
    {
        return height;
    }
    double getVolume()
    {
        return pi * radius * radius * height;
    }
    void printVolume()
    {
        cout << "The Volume of Cylinder is :" << pi * radius * radius * height << endl;
    }
};
 const double Cylinder::pi = 3.14;

int main()
{
     Cylinder c;
     c.printVolume();
     Cylinder c1(2,4);
     c1.printVolume();
     c1.setHeight(35);
     c1.printVolume();
     c1.getVolume();
    return 0;
}