#include <iostream>

using namespace std;

class Box {
private:
    int length;
    int width;
    int height;

public:

    Box() {
        length = 1;
        width = 1;
        height = 1;
    }

    Box(int l, int w,int h) {
        length = l;
        width = w;
        height = h;
    }

    Box(int value) {
        length=value;
        width=value;
        height=value;
    }

    int Volume() {
        return length * width * height;
    }
};

int main() {
    int choice;
    int length, width, height;

    do {
        cout << "\nMenu Options:" << endl;
        cout << "1. Volume with default values" << endl;
        cout << "2. Volume with length, breadth, and height with same value" << endl;
        cout << "3. Volume with different length, breadth, and height value" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                Box box1;
                cout << "Volume with default values: " << box1.Volume() << endl;
                break;
            }
            case 2: {
                cout << "Enter the value for length, width, and height: ";
                cin >> length;
                Box box2(length);
                cout << "Volume with same values: " << box2.Volume() << endl;
                break;
            }
            case 3: {
                cout << "Enter the values for length, width, and height: ";
                cin >> length >> width >> height;
                Box box3(length, width, height);
                cout << "Volume with different values: " << box3.Volume() << endl;
                break;
            }
            case 4: {
                cout << "Exit" << endl;
                break;
            }
            default: {
                cout << "Invalid choice!" << endl;
                break;
            }
        }
    } while (choice != 4);
}

   
