#include <iostream>
using namespace std;

class Address
{
    string building;
    string street;
    string city;
    int pin;

public:
    Address()
    {
        cout << "Default constructor called..." << endl;
    }
    void setstreet(string street)
    {
        this->street = street;
    }
    string getstreet(string street)
    {
        return street;
    }
    void setBuilding(string building)
    {
        this->building = building;
    }
    string getBuilding(string building)
    {
        return building;
    }
    void setcity(string city)
    {
        this->city = city;
    }
    string getcity(string city)
    {
        return city;
    }
    void setpin(int pin)
    {
        this->pin = pin;
    }
    int getpin(int pin)
    {
        return pin;
    }
    Address(string building, string street, string city, int pin)
    {
        this->building = building;
        this->street = street;
        this->city = city;
        this->pin = pin;
    }
    void displayAddress()
    {
        cout << building << endl;
        cout << street << endl;
        cout << city << endl;
        cout << pin << endl;
    }
    void accept()
    {
        cout << "Enter building name :";
        cin >> building;
        cout << "Enter street name :";
        cin >> street;
        cout << "Enter city name :";
        cin >> city;
        cout << "Enter the pincode :";
        cin >> pin;
        displayAddress();
    }
};

int main()
{
    int choice;
    string building;
    string street;
    string city;
    int pin;

    do
    {
        cout << "0.EXIT " << endl;
        cout << "1.User Addresss: " << endl;
        cout << "2.Displaying default Address : " << endl;
        cout << "3.Accepting new Address : " << endl;
        cout << "Enter your choice  - ";
        cin >> choice;
        switch (choice)
        {

        case 0:
            cout << "THANK YOU " << endl;
            break;
        case 1:
        {
            cout << "Enter the building name:\n";
            cin >> building;
            cout << "Enter the street name:\n";
            cin >> street;
            cout << "Enter your city:\n";
            cin >> city;
            cout << "Enter pin code:\n";
            cin >> pin;
            Address a1(building, street, city, pin);
            a1.displayAddress();

        }
        break;
        case 2:
        {
            Address a2;
            a2.setBuilding("sunbeam ");
            a2.setcity("Karad");
            a2.setstreet("shaniwar peth");
            a2.setpin(411501);
            a2.displayAddress();
            
        }
        break;
        case 3:
        {
            Address a3;
            a3.accept();
            
        }
        break;
        }

    } while (choice != 0);

    return 0;
}