

#include<iostream>
using namespace std;

class Date
{   
    private :

    int day;
    int month;
    int year;

    public :

    Date()
    {
        this->day=24;
        this->month=03;
        this->year=2024;
    }

    void acceptData()
    {
        cout<<"Enter Day : ";
        cin>>day;
        cout<<"Enter Month : ";
        cin>>month;
        cout<<"Enter Year : ";
        cin>>year;
    }

    void displayData()
    {
        cout<<"Date : "<<day<<" - "<<month<<" - "<<year<<endl;
    }
};

class Person
{   
    private :
    
    string name;
    string address;
    Date dobj;

    public :

    Person()
    {
        this->name="Empty";
        this->address="Empty";
    }
    //virtual void acceptdata()
    void acceptData()
    {
        cout<<"* Inside Person Class *"<<endl;
        cout<<"Enter Name : ";
        cin>>name;
        cout<<"Enter Address : ";
        cin>>address;
        cout<<"Birthdate : "<<endl;
        dobj.acceptData();
        
    }
    // virtual void diaplaydata()
    void displayData()
    {
        cout<<"Name : "<<name<<endl;
        cout<<"Address :"<<address<<endl ;
        cout<<"Birthdate : ";
        dobj.displayData();
       
    }
};

class Employee: public Person 
{
    private :

    int id;
    double sal;
    string dept;
    Date dobj;  
    

    public : 

    Employee()
    {
        this->id=000;
        this->sal=0;
        this->dept=" ";
        
    }

    void acceptData()
    {   
        cout<<"* Inside Employee Class *"<<endl;
        cout<<"Enter Id : ";
        cin>>id;
        cout<<"Enter Salary : ";
        cin>>sal;
        cout<<"Enter Department : ";
        cin>>dept;
        cout<<"Joining Date : "<<endl;
        dobj.acceptData();
        Person::acceptData();
    }

    void displayData()
    {
        cout<<"Id - "<<id<<endl;
        cout<<"Salary - "<<sal<<endl;
        cout<<"Department - "<<dept<<endl;
        cout<<"Joining Date : ";
        dobj.displayData();
        Person::displayData();
    }
};

int main()
{
   /* Person p;
    p.acceptData();
    p.displayData();
    
    Employee e;
    e.acceptData();
    e.displayData();*/
    Person *ptr=new Employee();
    ptr->acceptData();
    ptr->displayData();

    return 0;
}
