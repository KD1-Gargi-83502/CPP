/*A shop sells book or tapes. The Book class holds id, title, author, and price; whereas Tape class
holds id, title, artist, and price. There is 5% discount on tapes, while 10% discount on books.
Assuming that each user purchase 3 products (either book or tape), calculate final bill. The program
should be menu driven and should not cause memory leakage.
Hint - Create class Product and inherit into Book and Tape. Also create array like Product* arr[3]*/

#include <iostream>
#include <string>
using namespace std;

class Product {
private:
    int id;
    string title;
    double price;

public:
void setPrice(double price){
    this->price=price;
}
double getPrice()
{
    return price;
}
    virtual void accept() {
        cout << "Product ID: ";
        cin >> id;
        cout << "Product Title: ";
        cin >> title;
        cout << "Product Price: ";
        cin >> price;
    }

    virtual void display() {
        cout << "Product ID: " << id << endl;
        cout << "Product Title: " << title << endl;
        cout << "Product Price: " << price << endl;
    }
};

class Book : public Product {
private:
    string author;

public:
    void accept()  {
        Product::accept();
        cout << "Author Name: ";
        cin >> author;
         setPrice((getPrice()-getPrice()*0.10));
    }

    void display()  {
        cout << "Book Details:" << endl;
        Product::display();
        cout << "Author Name: " << author << endl;
    }
};

class Tape : public Product {
private:
    string artist;

public:
    void accept()  {
        Product::accept();
        cout << "Artist Name: ";
        cin >> artist;
        setPrice(getPrice()-getPrice()*0.05);
    }

    void display()  {
        cout << "Tape Details:" << endl;
        Product::display();
        cout << "Artist Name: " << artist << endl;
    }
};

int main() {
    Product *ptr[3];
    int index = 0;
    int choice;

    do {
        cout << "Press 0 to EXIT" << endl;
        cout << "Press 1 to Add a BOOK" << endl;
        cout << "Press 2 to Add a TAPE" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 0:
                cout << "Thank You..." << endl;
                break;
            case 1:
                if (index < 3) {
                    ptr[index] = new Book();
                    ptr[index]->accept();
                    index++;
                } else {
                    cout << "Array is full." << endl;
                }
                break;
            case 2:
                if (index < 3) {
                    ptr[index] = new Tape();
                    ptr[index]->accept();
                    index++;
                } else {
                    cout << "Array is full." << endl;
                }
                case 3:
                {
                     int total=0;
                    for(int i=0;i<index;i++)
                    {
                    total += ptr[i]->getPrice();
                    }
                   
                    

                    cout<< "Total Bills"<< total;
                }
                break;
            default:
                cout << "Wrong choice." << endl;
                break;
        }
    } while (choice != 0);

    // Display all products
    for (int i = 0; i < index; ++i) {
        ptr[i]->display();
        cout << endl;
    }

    // Delete dynamically allocated objects
    for (int i = 0; i < index; ++i) {
        delete ptr[i];
    }

    return 0;
}